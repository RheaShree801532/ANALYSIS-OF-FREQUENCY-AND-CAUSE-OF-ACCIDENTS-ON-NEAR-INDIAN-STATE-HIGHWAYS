import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns


df = pd.read_csv("C:/Users/Mrunal/Downloads/MBA-IT/Semester 2/(FDS) Fundamentals of Data Science/Road.csv")

# Time vs number of accidents - bar chart
plt.figure(figsize=(12, 6))
sns.countplot(x='Time', data=df)
plt.title('Time vs Number of Accidents')
plt.xlabel('Time')
plt.ylabel('Number of Accidents')
plt.xticks(rotation=45)
plt.show()

# Age_band_of_driver vs number of accidents - pie chart
plt.figure(figsize=(10, 8))
df['Age_band_of_driver'].value_counts().plot.pie(autopct='%1.1f%%')
plt.title('Age Band of Driver vs Number of Accidents')
plt.ylabel('')
plt.show()

# Sex of driver vs number of accidents - pie chart
plt.figure(figsize=(6, 6))
df['Sex_of_driver'].value_counts().plot.pie(autopct='%1.1f%%', colors=['skyblue', 'lightcoral'])
plt.title('Sex of Driver vs Number of Accidents')
plt.ylabel('')
plt.show()

# Driving experience vs number of accidents - pie chart
plt.figure(figsize=(8, 8))
df['Driving_experience'].value_counts().plot.pie(autopct='%1.1f%%')
plt.title('Driving Experience vs Number of Accidents')
plt.ylabel('')
plt.show()

# Road_surface_conditions vs. Number of Accidents - stacked bar chart
plt.figure(figsize=(12, 6))
sns.countplot(x='Road_surface_conditions', data=df, hue='Accident_severity')
plt.title('Road Surface Conditions vs Number of Accidents')
plt.xlabel('Road Surface Conditions')
plt.ylabel('Number of Accidents')
plt.show()

# Weather_conditions vs. Number of Accidents - stacked bar chart
plt.figure(figsize=(12, 6))
sns.countplot(x='Weather_conditions', data=df, hue='Accident_severity')
plt.title('Weather Conditions vs Number of Accidents')
plt.xlabel('Weather Conditions')
plt.ylabel('Number of Accidents')
plt.show()

# Area_accident_occurred vs. Number of Accidents - heat map
plt.figure(figsize=(12, 8))
heatmap_data = pd.crosstab(df['Area_accident_occured'], df['Accident_severity'])
sns.heatmap(heatmap_data, cmap='YlGnBu', annot=True, fmt='d')
plt.title('Area Accident Occurred vs Number of Accidents')
plt.xlabel('Accident Severity')
plt.ylabel('Area Accident Occurred')
plt.show()

# Type of collision vs number of accidents - bubble chart
plt.figure(figsize=(12, 6))
sns.scatterplot(x='Type_of_collision', y='Number_of_casualties', size='Number_of_vehicles_involved', data=df)
plt.title('Type of Collision vs Number of Accidents')
plt.xlabel('Type of Collision')
plt.ylabel('Number of Accidents')
plt.show()

# Lanes_or_Medians vs. Number of Accidents - bar chart
plt.figure(figsize=(12, 6))
sns.countplot(x='Lanes_or_Medians', data=df)
plt.title('Lanes or Medians vs Number of Accidents')
plt.xlabel('Lanes or Medians')
plt.ylabel('Number of Accidents')
plt.show()

# Road_alignment vs. Number of Accidents - bar chart
plt.figure(figsize=(12, 6))
sns.countplot(x='Road_allignment', data=df)
plt.title('Road Alignment vs Number of Accidents')
plt.xlabel('Road Alignment')
plt.ylabel('Number of Accidents')
plt.show()

# Types_of_Junction vs. Number of Accidents - bar chart
plt.figure(figsize=(12, 6))
sns.countplot(x='Types_of_Junction', data=df)
plt.title('Types of Junction vs Number of Accidents')
plt.xlabel('Types of Junction')
plt.ylabel('Number of Accidents')
plt.show()
